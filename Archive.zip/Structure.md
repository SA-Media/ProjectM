/output
  └── /docs
        ├── prd.md
        ├── frontend.md
        ├── backend.md
        └── third-party-libraries.md
